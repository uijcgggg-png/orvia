package app.orvia.companion;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/** Multi-step agent: reads the screen, asks the model for the next action, runs it, repeats (max 25 steps). */
final class AgentRunner {
    static volatile boolean running = false;
    static volatile boolean stop = false;
    static final int MAX = 25;
    static final String URL = "https://orvia-rose.vercel.app/api/agent";
    private static final Pattern FIN_PKG = Pattern.compile("bank|wallet|paypal|payment|spay|gpay|walletnfc|revolut|binance|fawry|instapay|vodafonecash|etisalatcash|\\.pay\\.|\\.pay$|banquemisr|nbe|qnb|cib\\.", Pattern.CASE_INSENSITIVE);
    private static final Pattern FIN_NAME = Pattern.compile("bank|wallet|paypal|pay\\b|cash|instapay|fawry|revolut|binance|بنك|محفظ|كاش|فودافون كاش|انستا ?باي|فوري", Pattern.CASE_INSENSITIVE);
    private static final Pattern RISKY = Pattern.compile("\\b(send|post|publish|share|submit|confirm|delete|remove|erase|buy|purchase|order|pay|checkout|transfer|tweet|reply|sign out|log out|uninstall|reset|factory|forward)\\b|إرسال|ارسال|نشر|شارك|مشاركة|تأكيد|حذف|مسح|شراء|اشتري|دفع|تحويل|إلغاء التثبيت|تسجيل الخروج|إعادة ضبط", Pattern.CASE_INSENSITIVE);

    private final OrviaService s; private final String dev, sec, goal;
    private final Handler main = new Handler(Looper.getMainLooper());
    private List<AccessibilityNodeInfo> nodes = new ArrayList<>();
    private String lastTyped = null;
    private LinearLayout bar; private TextView barText; private WindowManager wm;

    AgentRunner(OrviaService s, String dev, String sec, String goal) { this.s = s; this.dev = dev; this.sec = sec; this.goal = goal; }

    String run() throws Exception {
        if (running) throw new Exception("Another task is already running on the phone.");
        if (goal == null || goal.trim().isEmpty()) throw new Exception("empty task");
        if (FIN_NAME.matcher(goal).find()) throw new Exception("Refused: tasks about banking, wallets or payments are not allowed.");
        if (!s.confirm("Let Orvia control your phone for this task?\n\n" + goal + "\n\nUp to " + MAX + " steps. A STOP button stays on screen. It asks you again before sending, posting, deleting, buying or changing settings. It never types passwords."))
            throw new Exception("Declined on the phone.");
        running = true; stop = false; lastTyped = null;
        showBar("Orvia is working...");
        StringBuilder hist = new StringBuilder(); String lastSig = ""; int same = 0;
        try {
            for (int step = 1; step <= MAX; step++) {
                if (stop) throw new Exception("Stopped by you after " + (step - 1) + " steps.");
                Thread.sleep(step == 1 ? 600 : 1000);
                String pkg = snapshotPkg(); String scr = snapshot();
                if (FIN_PKG.matcher(pkg).find()) throw new Exception("Refused: this looks like a banking or payment app (" + pkg + ").");
                JSONObject req = new JSONObject().put("device_id", dev).put("secret", sec).put("goal", goal).put("step", step).put("max", MAX)
                    .put("pkg", pkg).put("history", hist.toString()).put("screen", scr);
                JSONObject a = null; String err = "";
                for (int tries = 0; tries < 3 && a == null; tries++) {
                    try { a = Api.post(URL, req).getJSONObject("action"); }
                    catch (Api.ApiError e) {
                        err = e.getMessage();
                        if (err.contains("DAILYCAP")) throw new Exception("Daily limit for phone tasks reached. Try tomorrow.");
                        if (err.contains("unauthorized")) throw new Exception("Device not authorized.");
                        Thread.sleep(err.contains("COOLDOWN") ? 6000 : 2000);
                    }
                }
                if (a == null) throw new Exception("The AI model did not answer (" + err + "). Free models are busy or limited; try again later.");
                String act = a.optString("action"), thought = a.optString("thought");
                if (act.equals("done")) return a.optString("summary", "Done.") + " (" + step + " steps)";
                if (act.equals("fail")) throw new Exception(a.optString("reason", "Could not complete the task."));
                setBar("Step " + step + "/" + MAX + ": " + (thought.isEmpty() ? act : thought));
                String sig = a.toString() + scr.hashCode();
                same = sig.equals(lastSig) ? same + 1 : 0; lastSig = sig;
                if (same >= 2) throw new Exception("Stuck: the same action repeated without progress.");
                String res;
                try { res = exec(a, pkg); } catch (Exception e) { res = "ERROR: " + e.getMessage(); if (String.valueOf(e.getMessage()).startsWith("STOP:")) throw new Exception(e.getMessage().substring(5)); }
                hist.append(step).append(". ").append(a.toString()).append(" -> ").append(res).append("\n");
            }
            throw new Exception("Reached the " + MAX + "-step limit without finishing.");
        } finally { running = false; hideBar(); }
    }

    // ---- screen
    private String snapshotPkg() { AccessibilityNodeInfo r = s.getRootInActiveWindow(); return r == null ? "" : String.valueOf(r.getPackageName()); }

    private String snapshot() {
        nodes = new ArrayList<>(); StringBuilder sb = new StringBuilder();
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "(no readable screen: it may be protected, loading, or a game)";
        walk(root, sb, 0);
        if (nodes.isEmpty()) return "(screen has no readable elements: custom-drawn app, game or protected screen. Try tap_xy, scroll, back or fail)";
        return sb.toString();
    }

    private void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || nodes.size() >= 140 || depth > 40) return;
        if (n.isVisibleToUser()) {
            CharSequence t = n.getText(), d = n.getContentDescription();
            boolean pw = n.isPassword();
            String label = pw ? "" : (t != null && t.length() > 0 ? t.toString() : (d != null ? d.toString() : ""));
            if (label.length() > 100) label = label.substring(0, 100) + "...";
            boolean useful = pw || !label.isEmpty() || n.isClickable() || n.isEditable() || n.isScrollable() || n.isCheckable();
            if (useful) {
                Rect r = new Rect(); n.getBoundsInScreen(r);
                String cls = String.valueOf(n.getClassName()); cls = cls.substring(cls.lastIndexOf('.') + 1);
                StringBuilder fl = new StringBuilder();
                if (n.isClickable()) fl.append("click,"); if (n.isEditable()) fl.append("edit,"); if (n.isScrollable()) fl.append("scroll,");
                if (n.isCheckable()) fl.append(n.isChecked() ? "checked," : "unchecked,"); if (n.isFocused()) fl.append("focused,");
                if (pw) fl.append("PASSWORD-never-type,");
                sb.append('[').append(nodes.size()).append("] ").append(cls).append(" \"").append(label.replace("\n", " ").replace("\"", "'")).append("\" ").append(fl)
                  .append('@').append(r.centerX()).append(',').append(r.centerY()).append('\n');
                nodes.add(n);
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb, depth + 1);
    }

    private String label(AccessibilityNodeInfo n) {
        CharSequence t = n.getText(), d = n.getContentDescription();
        return t != null && t.length() > 0 ? t.toString() : (d != null ? d.toString() : String.valueOf(n.getClassName()));
    }

    // ---- actions
    private String exec(JSONObject a, String pkg) throws Exception {
        String act = a.optString("action"); boolean risky = a.optBoolean("risky", false);
        boolean settings = pkg.contains("settings");
        switch (act) {
            case "tap": {
                AccessibilityNodeInfo n = node(a.optInt("index", -1)); String lb = label(n);
                if (n.isPassword()) throw new Exception("never interact with password fields");
                if (risky || settings || RISKY.matcher(lb).find()) ask("Tap \"" + lb + "\" in " + pkg + "?");
                if (!clickNode(n)) throw new Exception("could not tap that element");
                return "tapped \"" + lb + "\"";
            }
            case "tap_xy": {
                int x = a.optInt("x"), y = a.optInt("y");
                if (risky || settings) ask("Tap the screen at " + x + "," + y + " in " + pkg + "?");
                if (!tapXY(x, y)) throw new Exception("tap failed"); return "tapped " + x + "," + y;
            }
            case "type": {
                AccessibilityNodeInfo n = node(a.optInt("index", -1)); String t = a.optString("text");
                if (n.isPassword() || !n.isEditable()) throw new Exception("not a text box (or password): cannot type");
                if (t.isEmpty() || t.length() > 500) throw new Exception("text must be 1-500 characters");
                if (settings) ask("Type \"" + t + "\" in Settings?");
                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                android.os.Bundle b = new android.os.Bundle();
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t);
                if (!n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) throw new Exception("text box refused the text");
                lastTyped = t; return "typed text";
            }
            case "scroll": return scroll(a.optString("direction", "down"));
            case "press": {
                String k = a.optString("key");
                if (k.equals("back")) { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); return "back"; }
                if (k.equals("home")) { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return "home"; }
                if (k.equals("recents")) { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); return "recents"; }
                if (k.equals("enter")) {
                    ask("Press Enter / send in " + pkg + "?");
                    AccessibilityNodeInfo f = s.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                    if (f != null && android.os.Build.VERSION.SDK_INT >= 30 && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())) return "enter";
                    throw new Exception("enter not supported here; tap the Send button instead");
                }
                throw new Exception("unknown key");
            }
            case "open_app": {
                String nm = a.optString("name");
                if (FIN_NAME.matcher(nm).find()) throw new Exception("STOP:Refused: banking, wallet and payment apps are not allowed.");
                String r = s.openApp(nm); Thread.sleep(1500); return r;
            }
            case "wait": Thread.sleep(Math.max(1, Math.min(a.optInt("seconds", 2), 5)) * 1000L); return "waited";
            default: throw new Exception("unknown action");
        }
    }

    private void ask(String what) throws Exception {
        String t = what + (lastTyped != null ? "\n\nText typed so far:\n\"" + lastTyped + "\"" : "");
        if (!s.confirm("Orvia is about to do this:\n\n" + t)) throw new Exception("STOP:You denied an action, so the task was stopped.");
    }

    private AccessibilityNodeInfo node(int i) throws Exception {
        if (i < 0 || i >= nodes.size()) throw new Exception("no such element index " + i);
        return nodes.get(i);
    }

    private boolean clickNode(AccessibilityNodeInfo n) throws Exception {
        AccessibilityNodeInfo c = n; for (int i = 0; i < 6 && c != null; i++) { if (c.isClickable() && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.getParent(); }
        Rect r = new Rect(); n.getBoundsInScreen(r); return tapXY(r.centerX(), r.centerY());
    }

    private boolean tapXY(int x, int y) throws Exception {
        Path p = new Path(); p.moveTo(x, y);
        return gesture(new GestureDescription.StrokeDescription(p, 0, 60));
    }

    private String scroll(String dir) throws Exception {
        AccessibilityNodeInfo sc = null;
        for (AccessibilityNodeInfo n : nodes) if (n.isScrollable()) { sc = n; break; }
        boolean fwd = dir.equals("down") || dir.equals("right");
        if (sc != null && sc.performAction(fwd ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return "scrolled " + dir;
        android.util.DisplayMetrics m = s.getResources().getDisplayMetrics(); int w = m.widthPixels, h = m.heightPixels;
        Path p = new Path();
        if (dir.equals("down")) { p.moveTo(w / 2f, h * 0.7f); p.lineTo(w / 2f, h * 0.3f); }
        else if (dir.equals("up")) { p.moveTo(w / 2f, h * 0.3f); p.lineTo(w / 2f, h * 0.7f); }
        else if (dir.equals("right")) { p.moveTo(w * 0.8f, h / 2f); p.lineTo(w * 0.2f, h / 2f); }
        else { p.moveTo(w * 0.2f, h / 2f); p.lineTo(w * 0.8f, h / 2f); }
        gesture(new GestureDescription.StrokeDescription(p, 0, 350)); return "swiped " + dir;
    }

    private boolean gesture(GestureDescription.StrokeDescription sd) throws Exception {
        final CountDownLatch l = new CountDownLatch(1); final boolean[] ok = {false};
        boolean sent = s.dispatchGesture(new GestureDescription.Builder().addStroke(sd).build(), new AccessibilityService.GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) { ok[0] = true; l.countDown(); }
            @Override public void onCancelled(GestureDescription g) { l.countDown(); }
        }, null);
        if (!sent) return false; l.await(3, TimeUnit.SECONDS); return ok[0];
    }

    // ---- overlay bar with STOP
    private void showBar(final String text) {
        main.post(new Runnable() { public void run() {
            wm = (WindowManager) s.getSystemService(android.content.Context.WINDOW_SERVICE);
            bar = new LinearLayout(s); bar.setOrientation(LinearLayout.HORIZONTAL); bar.setPadding(24, 12, 24, 12); bar.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable bg = new GradientDrawable(); bg.setColor(0xE6101420); bg.setCornerRadius(40); bar.setBackground(bg);
            barText = new TextView(s); barText.setTextColor(Color.WHITE); barText.setTextSize(13); barText.setMaxLines(2); barText.setText(text);
            Button st = new Button(s); st.setText("STOP"); st.setTextColor(Color.WHITE); st.setBackgroundColor(0xFFD32F2F); st.setOnClickListener(v -> { stop = true; barText.setText("Stopping..."); });
            bar.addView(barText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); bar.addView(st);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.TOP; p.y = 80; p.horizontalMargin = 0.03f;
            try { wm.addView(bar, p); } catch (Exception ignore) { }
        }});
    }
    private void setBar(final String t) { main.post(() -> { if (barText != null) barText.setText(t); }); }
    private void hideBar() { main.post(() -> { try { if (bar != null) wm.removeView(bar); } catch (Exception ignore) { } bar = null; }); }
}
