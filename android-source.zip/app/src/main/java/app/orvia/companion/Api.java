package app.orvia.companion;

import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

final class Api {
    static final String SB = "https://wdiukcpegqeifllhauqf.supabase.co";
    static final String KEY = "sb_publishable_-3O5QNXd4bTtFu2aOUIhkA_Ef3RVNiz";

    static class ApiError extends Exception { ApiError(String m) { super(m); } }

    static JSONObject post(String url, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(90000);
        c.setRequestProperty("Content-Type", "application/json"); c.setDoOutput(true);
        try (OutputStream o = c.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) try (BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            char[] buf = new char[8192]; int n; while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
        }
        JSONObject j; try { j = new JSONObject(sb.toString()); } catch (Exception e) { j = new JSONObject(); }
        if (code >= 400) throw new ApiError(j.optString("error", "HTTP " + code));
        return j;
    }

    /** Calls a Supabase RPC function. Returns JSONObject, JSONArray or null. */
    static Object rpc(String fn, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(SB + "/rest/v1/rpc/" + fn).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000); c.setReadTimeout(30000);
        c.setRequestProperty("apikey", KEY);
        c.setRequestProperty("Content-Type", "application/json");
        c.setDoOutput(true);
        try (OutputStream o = c.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) try (BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            char[] buf = new char[8192]; int n; while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
        }
        String t = sb.toString().trim();
        if (code >= 400) {
            String m = t;
            try { m = new JSONObject(t).optString("message", t); } catch (Exception ignore) {}
            throw new ApiError(m);
        }
        if (t.isEmpty()) return null;
        return new JSONTokener(t).nextValue();
    }
}
