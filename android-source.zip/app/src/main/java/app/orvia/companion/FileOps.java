package app.orvia.companion;

import android.os.Build;
import android.os.Environment;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Locale;

/** File actions, limited to shared storage (/storage/emulated/0). Only run after the on-screen Allow. */
final class FileOps {
    static String run(String act, JSONObject a) throws Exception {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) throw new Exception("All files access is not granted. Open Orvia Companion and finish the setup checklist.");
        File root = Environment.getExternalStorageDirectory().getCanonicalFile();
        switch (act) {
            case "files_list": {
                File d = resolve(root, a.optString("path", "/"));
                if (!d.isDirectory()) throw new Exception("not a folder: " + rel(root, d));
                File[] fs = d.listFiles(); if (fs == null) throw new Exception("cannot open folder");
                Arrays.sort(fs); StringBuilder sb = new StringBuilder(rel(root, d) + ":\n"); int n = 0;
                for (File f : fs) { if (n++ >= 200) { sb.append("... (more)\n"); break; } sb.append(f.isDirectory() ? "[folder] " : "").append(f.getName()).append(f.isDirectory() ? "" : " (" + f.length() + " B)").append('\n'); }
                return sb.toString();
            }
            case "files_search": {
                String q = a.optString("query").toLowerCase(Locale.ROOT).trim(); if (q.isEmpty()) throw new Exception("empty search");
                ArrayDeque<File> dq = new ArrayDeque<>(); dq.add(root); StringBuilder sb = new StringBuilder(); int seen = 0, found = 0;
                while (!dq.isEmpty() && seen < 30000 && found < 50) {
                    File[] fs = dq.poll().listFiles(); if (fs == null) continue;
                    for (File f : fs) { seen++; if (f.getName().toLowerCase(Locale.ROOT).contains(q)) { found++; sb.append(rel(root, f)).append(f.isDirectory() ? "/" : " (" + f.length() + " B)").append('\n'); if (found >= 50) break; }
                        if (f.isDirectory() && !f.getName().startsWith(".")) dq.add(f); }
                }
                return found == 0 ? "No files found for \"" + q + "\"." : sb.toString();
            }
            case "files_read": {
                File f = resolve(root, a.optString("path"));
                if (!f.isFile()) throw new Exception("not a file");
                if (f.length() > 2_000_000) throw new Exception("file too big to read (over 2 MB)");
                byte[] b = new byte[(int) Math.min(f.length(), 20000)];
                try (FileInputStream in = new FileInputStream(f)) { int r = in.read(b); if (r < b.length) b = Arrays.copyOf(b, Math.max(r, 0)); }
                return new String(b, "UTF-8") + (f.length() > 20000 ? "\n...(shortened to the first 20 KB)" : "");
            }
            default: { // files_send
                File f = resolve(root, a.optString("path"));
                if (!f.isFile()) throw new Exception("not a file");
                if (f.length() > 600_000) throw new Exception("file too big to send (limit 600 KB)");
                byte[] b = new byte[(int) f.length()];
                try (DataInputStream in = new DataInputStream(new FileInputStream(f))) { in.readFully(b); }
                return "orvia-file:" + f.getName().replace("|", "_") + "|" + java.net.URLConnection.guessContentTypeFromName(f.getName()) + "|" + Base64.encodeToString(b, Base64.NO_WRAP);
            }
        }
    }
    private static File resolve(File root, String p) throws Exception {
        String s = p == null ? "" : p.trim(); if (s.startsWith("/storage/emulated/0")) s = s.substring("/storage/emulated/0".length());
        File f = new File(root, s).getCanonicalFile();
        if (!f.getPath().equals(root.getPath()) && !f.getPath().startsWith(root.getPath() + "/")) throw new Exception("path outside shared storage");
        return f;
    }
    private static String rel(File root, File f) { String r = f.getPath().substring(root.getPath().length()); return r.isEmpty() ? "/" : r; }
}
