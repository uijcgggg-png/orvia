package app.orvia.companion;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private TextView title, code, info, state;
    private Button copy, access, unlink;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences p;
    private volatile boolean alive;
    private long expiresAt = 0; private volatile boolean busy;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("orvia", MODE_PRIVATE);
        LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); v.setPadding(56, 96, 56, 56); v.setGravity(Gravity.CENTER_HORIZONTAL);
        title = tv(v, "Orvia Companion", 26, true);
        info = tv(v, "", 15, false);
        code = tv(v, "", 20, true); code.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); code.setTextIsSelectable(true); code.setPadding(0, 40, 0, 20);
        state = tv(v, "", 14, false);
        copy = btn(v, "Copy code", x -> { ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("code", code.getText())); state.setText("Copied. Paste it in the Orvia chat."); });
        access = btn(v, "1) Turn on Orvia in Accessibility settings", x -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        unlink = btn(v, "Disconnect this phone", x -> { p.edit().clear().apply(); expiresAt = 0; });
        setContentView(v);
    }
    private TextView tv(LinearLayout v, String s, int sp, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setGravity(Gravity.CENTER); t.setTextColor(0xff111111); if (bold) t.setTypeface(null, Typeface.BOLD); t.setPadding(0, 12, 0, 12); v.addView(t); return t; }
    private Button btn(LinearLayout v, String s, android.view.View.OnClickListener c) { Button b = new Button(this); b.setText(s); b.setOnClickListener(c); b.setAllCaps(false); v.addView(b); return b; }

    @Override protected void onResume() { super.onResume(); alive = true; ui.post(tick); }
    @Override protected void onPause() { super.onPause(); alive = false; }

    private boolean serviceOn() { return OrviaService.inst != null; }

    private final Runnable tick = new Runnable() { public void run() {
        if (!alive) return;
        boolean paired = p.getBoolean("paired", false);
        access.setText(serviceOn() ? "Accessibility: ON (tap to review)" : "1) Turn on Orvia in Accessibility settings");
        unlink.setVisibility(paired ? android.view.View.VISIBLE : android.view.View.GONE);
        copy.setVisibility(paired ? android.view.View.GONE : android.view.View.VISIBLE);
        if (paired) {
            info.setText("This phone is linked to your Orvia account.\nOrvia can now send it actions. Each sensitive action asks you first on screen.\nTo revoke: Disconnect here, or remove the device in Orvia > Settings > Devices.");
            code.setText("Linked"); state.setText(serviceOn() ? "Ready." : "Turn on the accessibility service so actions can run.");
        } else {
            info.setText("To link this phone: send this code to the Orvia chat (it works once, for 40 seconds, for one account).");
            long left = (expiresAt - System.currentTimeMillis()) / 1000;
            if (p.getString("device_id", null) == null || left <= 0) register();
            else { state.setText("Expires in " + left + " s"); poll(true); }
        }
        ui.postDelayed(this, 1500);
    }};

    private void register() {
        if (busy) return; busy = true;
        new Thread(() -> {
            try {
                JSONObject r = (JSONObject) Api.rpc("device_register", new JSONObject().put("p_name", android.os.Build.MODEL).put("p_platform", "android"));
                String c = r.getString("code"); StringBuilder f = new StringBuilder("ORV");
                for (int i = 0; i < c.length(); i += 5) f.append('-').append(c, i, Math.min(c.length(), i + 5));
                p.edit().putString("device_id", r.getString("device_id")).putString("secret", r.getString("secret")).putBoolean("paired", false).apply();
                expiresAt = System.currentTimeMillis() + 40000;
                ui.post(() -> code.setText(f.toString()));
            } catch (Exception e) { ui.post(() -> state.setText("No connection. Retrying...")); }
            busy = false;
        }).start();
    }

    private void poll(boolean unpaired) {
        final String dev = p.getString("device_id", null), sec = p.getString("secret", null);
        if (dev == null || busy) return; busy = true;
        new Thread(() -> {
            try {
                JSONObject s = (JSONObject) Api.rpc("device_status", new JSONObject().put("p_device", dev).put("p_secret", sec));
                if (s.optBoolean("paired")) p.edit().putBoolean("paired", true).apply();
                else if (s.optBoolean("expired")) { expiresAt = 0; p.edit().clear().apply(); }
            } catch (Api.ApiError e) { if (String.valueOf(e.getMessage()).contains("unauthorized")) { p.edit().clear().apply(); expiresAt = 0; } }
            catch (Exception ignore) { }
            busy = false;
        }).start();
    }
}
