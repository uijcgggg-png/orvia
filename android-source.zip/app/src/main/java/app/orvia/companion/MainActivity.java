package app.orvia.companion;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private TextView title, checklist, code, info, state;
    private Button next, copy, unlink;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences p;
    private volatile boolean alive;
    private long expiresAt = 0; private volatile boolean busy;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("orvia", MODE_PRIVATE);
        LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); v.setPadding(48, 80, 48, 48); v.setGravity(Gravity.CENTER_HORIZONTAL);
        title = tv(v, "Orvia Companion", 26, true);
        tv(v, "Step 1: allow what Orvia needs. Android only lets YOU grant some of these in system screens. Each one is asked once; the phone remembers it.", 14, false);
        checklist = tv(v, "", 16, false); checklist.setGravity(Gravity.START);
        next = btn(v, "", x -> nextStep());
        tv(v, "Step 2: link this phone", 16, true);
        info = tv(v, "", 14, false);
        code = tv(v, "", 19, true); code.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); code.setTextIsSelectable(true); code.setPadding(0, 24, 0, 12);
        state = tv(v, "", 14, false);
        copy = btn(v, "Copy code", x -> { ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("code", code.getText())); state.setText("Copied. Paste it in the Orvia chat."); });
        unlink = btn(v, "Disconnect this phone", x -> { p.edit().clear().apply(); expiresAt = 0; });
        ScrollView sv = new ScrollView(this); sv.addView(v); setContentView(sv);
    }
    private TextView tv(LinearLayout v, String s, int sp, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setGravity(Gravity.CENTER); t.setTextColor(0xff111111); if (bold) t.setTypeface(null, Typeface.BOLD); t.setPadding(0, 12, 0, 12); v.addView(t); return t; }
    private Button btn(LinearLayout v, String s, View.OnClickListener c) { Button b = new Button(this); b.setText(s); b.setOnClickListener(c); b.setAllCaps(false); v.addView(b); return b; }

    @Override protected void onResume() { super.onResume(); alive = true; ui.post(tick); }
    @Override protected void onPause() { super.onPause(); alive = false; }

    // ---- permission checklist
    private boolean okNotif() { return Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED; }
    private boolean okAccess() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return en != null && en.contains(new ComponentName(this, OrviaService.class).flattenToString());
    }
    private boolean okFiles() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
    }
    private boolean okBatt() { return ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName()); }

    private int nextIdx() { if (!okNotif()) return 0; if (!okFiles()) return 1; if (!okBatt()) return 2; if (!okAccess()) return 3; return -1; }

    private void nextStep() {
        int i = nextIdx();
        try {
            if (i == 0) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
            else if (i == 1) {
                if (Build.VERSION.SDK_INT >= 30) { try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); } }
                else requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, 2);
            } else if (i == 2) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
            } else if (i == 3) startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) { state.setText("Could not open that screen: " + e.getMessage()); }
    }

    private final Runnable tick = new Runnable() { public void run() {
        if (!alive) return;
        boolean n = okNotif(), f = okFiles(), bt = okBatt(), ac = okAccess();
        checklist.setText((n ? "✅ " : "⬜ ") + "Notifications\n" + (f ? "✅ " : "⬜ ") + "All files access (system screen)\n" + (bt ? "✅ " : "⬜ ") + "Run in background (battery)\n" + (ac ? "✅ " : "⬜ ") + "Accessibility (system screen)");
        int i = nextIdx();
        String[] names = {"Allow notifications", "Allow all files access", "Allow background battery", "Turn on Accessibility"};
        next.setVisibility(i < 0 ? View.GONE : View.VISIBLE);
        if (i >= 0) next.setText("Next: " + names[i]);
        if (i == 3 || (i < 0)) { /* accessibility hint */ }
        boolean paired = p.getBoolean("paired", false);
        unlink.setVisibility(paired ? View.VISIBLE : View.GONE);
        copy.setVisibility(paired ? View.GONE : View.VISIBLE);
        if (paired) {
            info.setText("This phone is linked to your Orvia account. Every action starts with your Run tap in the chat, and risky ones ask Allow here.\nTo revoke: Disconnect here or Orvia > Settings > Devices > Remove.");
            try { startForegroundService(new Intent(MainActivity.this, PollService.class)); } catch (Throwable ignore) { }
            long ago = (System.currentTimeMillis() - PollService.lastOk) / 1000;
            String conn = PollService.lastOk == 0 ? "Connecting..." : (ago < 15 ? "Connected to Orvia (online)" : "Last contact " + ago + " s ago");
            if (!PollService.lastErr.isEmpty()) conn = "Problem: " + PollService.lastErr;
            code.setText("Linked"); state.setText(conn + "\nAccessibility: " + (ac ? "ON" : "OFF (actions will fail until you turn it on)"));
        } else {
            info.setText("Send this code to the Orvia chat (works once, for 40 seconds, for one account).");
            long left = (expiresAt - System.currentTimeMillis()) / 1000;
            if (p.getString("device_id", null) == null || left <= 0) register();
            else { state.setText("Expires in " + left + " s"); poll(); }
        }
        ui.postDelayed(this, 1500);
    }};

    private void register() {
        if (busy) return; busy = true;
        new Thread(() -> {
            try {
                JSONObject r = (JSONObject) Api.rpc("device_register", new JSONObject().put("p_name", Build.MODEL).put("p_platform", "android"));
                String c = r.getString("code"); StringBuilder f = new StringBuilder("ORV");
                for (int i = 0; i < c.length(); i += 5) f.append('-').append(c, i, Math.min(c.length(), i + 5));
                p.edit().putString("device_id", r.getString("device_id")).putString("secret", r.getString("secret")).putBoolean("paired", false).apply();
                expiresAt = System.currentTimeMillis() + 40000;
                ui.post(() -> code.setText(f.toString()));
            } catch (Exception e) { ui.post(() -> state.setText("No connection. Retrying...")); }
            busy = false;
        }).start();
    }

    private void poll() {
        final String dev = p.getString("device_id", null), sec = p.getString("secret", null);
        if (dev == null || busy) return; busy = true;
        new Thread(() -> {
            try {
                JSONObject s = (JSONObject) Api.rpc("device_status", new JSONObject().put("p_device", dev).put("p_secret", sec));
                if (s.optBoolean("paired")) p.edit().putBoolean("paired", true).apply();
                else if (s.optBoolean("expired")) { expiresAt = 0; p.edit().clear().apply(); }
            } catch (Api.ApiError e) { if (String.valueOf(e.getMessage()).contains("unauthorized")) { p.edit().clear().apply(); expiresAt = 0; } }
            catch (Exception ignore) { }
            busy = false;
        }).start();
    }
}
