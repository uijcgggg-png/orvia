package app.orvia.companion;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Polls Orvia for commands and runs a fixed allowlist of actions. No shell, no arbitrary code. */
public class OrviaService extends AccessibilityService {
    static volatile OrviaService inst;
    private final Handler main = new Handler(Looper.getMainLooper());
    // Actions that need an on-screen Allow/Deny before they run.
    private static boolean needsConfirm(String a) {
        return a.equals("open_url") || a.equals("open_app") || a.equals("screenshot") || a.equals("type_text");
    }

    @Override protected void onServiceConnected() {
        inst = this;
        try { startForegroundService(new Intent(this, PollService.class)); } catch (Throwable ignore) { }
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public boolean onUnbind(Intent i) { inst = null; return super.onUnbind(i); }
    @Override public void onDestroy() { inst = null; super.onDestroy(); }

    private void report(String dev, String sec, String id, String st, String res) { report0(dev, sec, id, st, res); }
    static void report0(String dev, String sec, String id, String st, String res) {
        try { Api.rpc("device_report", new JSONObject().put("p_device", dev).put("p_secret", sec).put("p_cmd", id).put("p_status", st).put("p_result", res)); }
        catch (Exception ignore) { }
    }

    void handle(String dev, String sec, JSONObject c) {
        String id = c.optString("id"), act = c.optString("action");
        JSONObject args = c.optJSONObject("args"); if (args == null) args = new JSONObject();
        String st = "done", res;
        try {
            if (needsConfirm(act) && !confirm(describe(act, args))) { report(dev, sec, id, "rejected", "Declined on the phone."); return; }
            res = execute(act, args);
        } catch (Exception e) { st = "failed"; res = String.valueOf(e.getMessage()); }
        report(dev, sec, id, st, res);
    }

    private String describe(String act, JSONObject a) {
        switch (act) {
            case "open_url": return "Open this link?\n" + a.optString("url");
            case "open_app": return "Open the app \"" + a.optString("name") + "\"?";
            case "screenshot": return "Take a screenshot and send it to your Orvia chat?";
            case "type_text": return "Type this text into the selected box?\n" + a.optString("text");
            default: return act;
        }
    }

    private String execute(String act, JSONObject a) throws Exception {
        switch (act) {
            case "open_url": {
                String u = a.optString("url");
                if (!(u.startsWith("https://") || u.startsWith("http://")) || u.length() > 1000) throw new Exception("only http/https links allowed");
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i); return "opened " + u;
            }
            case "open_app": return openApp(a.optString("name"));
            case "volume": {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                String d = a.optString("direction"); int steps = Math.max(1, Math.min(a.optInt("steps", 3), 15));
                int dir;
                if (d.equals("up")) dir = AudioManager.ADJUST_RAISE; else if (d.equals("down")) dir = AudioManager.ADJUST_LOWER;
                else if (d.equals("mute")) dir = AudioManager.ADJUST_MUTE; else if (d.equals("unmute")) dir = AudioManager.ADJUST_UNMUTE;
                else throw new Exception("direction must be up, down, mute or unmute");
                for (int i = 0; i < ((dir == AudioManager.ADJUST_MUTE || dir == AudioManager.ADJUST_UNMUTE) ? 1 : steps); i++)
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, i == 0 ? AudioManager.FLAG_SHOW_UI : 0);
                return "volume " + d;
            }
            case "lock": if (!performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)) throw new Exception("lock not allowed"); return "locked";
            case "go_home": performGlobalAction(GLOBAL_ACTION_HOME); return "home";
            case "go_back": performGlobalAction(GLOBAL_ACTION_BACK); return "back";
            case "type_text": return typeText(a.optString("text"));
            case "screenshot": return screenshot();
            default: throw new Exception("action not allowed");
        }
    }

    private String openApp(String name) throws Exception {
        String want = name.trim().toLowerCase();
        if (want.isEmpty()) throw new Exception("no app name");
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
        ResolveInfo best = null;
        for (ResolveInfo r : l) {
            String lab = String.valueOf(r.loadLabel(pm)).toLowerCase();
            if (lab.equals(want)) { best = r; break; }
            if (best == null && lab.contains(want)) best = r;
        }
        if (best == null) throw new Exception("app not found: " + name);
        Intent i = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
        if (i == null) throw new Exception("cannot launch " + name);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        return "opened " + best.loadLabel(pm);
    }

    private String typeText(String t) throws Exception {
        if (t.isEmpty() || t.length() > 500) throw new Exception("text must be 1-500 characters");
        AccessibilityNodeInfo n = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (n == null || !n.isEditable()) throw new Exception("no text box selected on the phone");
        CharSequence cur = n.getText();
        String base = (cur == null || n.isShowingHintText()) ? "" : cur.toString();
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + t);
        if (!n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) throw new Exception("this text box refused the text");
        return "typed " + t.length() + " characters";
    }

    private String screenshot() throws Exception {
        if (Build.VERSION.SDK_INT < 30) throw new Exception("screenshots need Android 11 or newer");
        final Bitmap[] out = new Bitmap[1]; final String[] err = new String[1];
        final CountDownLatch l = new CountDownLatch(1);
        Thread.sleep(500); // let the approval box disappear first
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                    out[0] = hw.copy(Bitmap.Config.ARGB_8888, false); hw.recycle(); r.getHardwareBuffer().close();
                } catch (Throwable t) { err[0] = String.valueOf(t.getMessage()); }
                l.countDown();
            }
            @Override public void onFailure(int code) { err[0] = "screenshot failed (code " + code + ")"; l.countDown(); }
        });
        if (!l.await(10, TimeUnit.SECONDS) || out[0] == null) throw new Exception(err[0] != null ? err[0] : "screenshot timed out");
        Bitmap b = out[0]; int w = 720, h = Math.max(1, b.getHeight() * w / b.getWidth());
        Bitmap s = Bitmap.createScaledBitmap(b, w, h, true);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        s.compress(Bitmap.CompressFormat.JPEG, 60, bo);
        return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    /** Overlay with Allow / Deny. Returns false on Deny or after 60 s. */
    private boolean confirm(final String text) throws Exception {
        final CountDownLatch l = new CountDownLatch(1); final boolean[] ok = {false};
        final WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        final LinearLayout[] box = new LinearLayout[1];
        main.post(new Runnable() { public void run() {
            LinearLayout v = new LinearLayout(OrviaService.this); v.setOrientation(LinearLayout.VERTICAL); v.setPadding(48, 40, 48, 32);
            GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE); bg.setCornerRadius(40); v.setBackground(bg);
            TextView t = new TextView(OrviaService.this); t.setTextColor(Color.BLACK); t.setTextSize(17);
            t.setText("Orvia wants to do this on your phone:\n\n" + text); v.addView(t);
            LinearLayout row = new LinearLayout(OrviaService.this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0, 32, 0, 0);
            Button no = new Button(OrviaService.this); no.setText("Deny"); Button yes = new Button(OrviaService.this); yes.setText("Allow");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(no, lp); row.addView(yes, lp); v.addView(row);
            no.setOnClickListener(x -> l.countDown());
            yes.setOnClickListener(x -> { ok[0] = true; l.countDown(); });
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.CENTER; p.horizontalMargin = 0.05f;
            box[0] = v; wm.addView(v, p);
        }});
        l.await(60, TimeUnit.SECONDS);
        main.post(new Runnable() { public void run() { try { if (box[0] != null) wm.removeView(box[0]); } catch (Exception ignore) { } } });
        return ok[0];
    }
}
