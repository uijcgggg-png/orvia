package app.orvia.companion;

import android.app.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import org.json.JSONArray;
import org.json.JSONObject;

/** Foreground service: keeps polling Orvia so the phone stays "online" and Samsung does not kill it. */
public class PollService extends Service {
    static volatile long lastOk = 0;
    static volatile String lastErr = "";
    private volatile boolean run;
    private Thread t;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("orvia", "Orvia connection", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "orvia").setContentTitle("Orvia Companion is connected")
            .setContentText("Waiting for commands from your Orvia chat").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC); else startForeground(1, n);
        if (t == null || !t.isAlive()) { run = true; t = new Thread(this::loop, "orvia-poll"); t.start(); }
        return START_STICKY;
    }

    @Override public void onDestroy() { run = false; super.onDestroy(); }

    private void loop() {
        while (run) {
            SharedPreferences p = getSharedPreferences("orvia", MODE_PRIVATE);
            String dev = p.getString("device_id", null), sec = p.getString("secret", null);
            if (dev != null && sec != null && p.getBoolean("paired", false)) {
                try {
                    Object r = Api.rpc("device_poll", new JSONObject().put("p_device", dev).put("p_secret", sec));
                    lastOk = System.currentTimeMillis(); lastErr = "";
                    if (r instanceof JSONArray) {
                        JSONArray a = (JSONArray) r;
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject c = a.getJSONObject(i);
                            OrviaService s = OrviaService.inst;
                            if (s == null) OrviaService.report0(dev, sec, c.optString("id"), "failed",
                                "Accessibility is OFF on the phone. Open Orvia Companion > turn on Accessibility, then try again.");
                            else s.handle(dev, sec, c);
                        }
                    }
                } catch (Api.ApiError e) {
                    lastErr = String.valueOf(e.getMessage());
                    if (lastErr.contains("unauthorized")) p.edit().clear().apply();
                } catch (Exception e) { lastErr = "no internet"; }
            }
            try { Thread.sleep(3000); } catch (InterruptedException e) { return; }
        }
    }
}
